Shift/Reduce Conflicts

- array creation and lvalue reduction for ID .
- if then vs if then else conflict

Parse errors:
-test6.tig  fixed: lexer ID underscore , explistcomma to semi

-test8.tig check if adding parentheses should create a seqexp
